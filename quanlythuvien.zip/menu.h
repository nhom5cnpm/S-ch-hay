#ifndef MENU_H
#define MENU_H

#include "sinhvien.h"
#include "sach.h"
#include "muontra.h"

void Menu();
void ThemSach();
void SuaSach();
void XoaSach();
void ThemSinhVien();
void SuaSinhVien();
void XoaSinhVien();
void MuonSach();
void TraSach();
void ToanBoSach();
void ToanBoSinhVien();
void SachMotSinhVienMuon();
void ToanBoSachDuocMuon();
void Thoat();

#endif
